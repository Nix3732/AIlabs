import requests
from json import dumps as json_encode


def display_response_info(http_response):
    divider = "=" * 40
    print(f"\n{divider}\nДетали ответа:")
    print(f"Код состояния: {http_response.status_code}")

    print("\nЗаголовки ответа:")
    for h, v in http_response.headers.items():
        print(f"{h}: {v}")

    print("\nСодержимое ответа:")
    try:
        print(json_encode(http_response.json(), indent=4, ensure_ascii=False))
    except ValueError:
        print(http_response.text)


def fetch_options(endpoint):
    print(f"\nОтправка OPTIONS запроса на: {endpoint}")
    resp = requests.options(endpoint)
    display_response_info(resp)


def retrieve_data(api_url, query_params=None):
    print(f"\nЗапрос данных с: {api_url}")
    if query_params:
        print(f"\nПараметры запроса: {query_params}")
    resp = requests.get(api_url, params=query_params)
    display_response_info(resp)
    return resp


def submit_data(api_endpoint, form_data=None, json_payload=None):
    print(f"\nОтправка данных на: {api_endpoint}")
    if form_data:
        print(f"\nФорма данных: {form_data}")
    if json_payload:
        print(f"\nJSON данные:\n{json_encode(json_payload, indent=4)}")

    resp = requests.post(api_endpoint, data=form_data, json=json_payload)
    display_response_info(resp)
    return resp


def execute_tests():
    base_api_url = "https://httpbin.org"

    # Тестируем различные методы
    fetch_options(f"{base_api_url}/get")
    retrieve_data(f"{base_api_url}/get")
    retrieve_data(f"{base_api_url}/get", {"param1": "test", "param2": 123})
    submit_data(f"{base_api_url}/post", form_data={"login": "user", "token": "abc123"})
    submit_data(f"{base_api_url}/post", json_payload={"article": {"title": "Новый пост", "content": "Текст статьи"}})


if __name__ == "__main__":
    execute_tests()