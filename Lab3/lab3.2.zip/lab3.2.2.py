import matplotlib.pyplot as plt
import numpy as np
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression


iris_data = load_iris()
features = iris_data.data[:, 2:]
target = iris_data.target

clf = LogisticRegression(multi_class='multinomial',
                                solver='lbfgs',
                                max_iter=200)
clf.fit(features, target)

petal_l = features[:, 0]
petal_w = features[:, 1]

step_size = 0.02

length_min, length_max = petal_l.min() - 1, petal_l.max() + 1
width_min, width_max = petal_w.min() - 1, petal_w.max() + 1

grid_x, grid_y = np.meshgrid(
    np.arange(length_min, length_max, step_size),
    np.arange(width_min, width_max, step_size))

grid_predictions = clf.predict(np.c_[grid_x.ravel(), grid_y.ravel()]).reshape(grid_x.shape)

plt.figure(figsize=(12, 7))
plt.contourf(grid_x, grid_y, grid_predictions,
             alpha=0.3,
             cmap=plt.cm.Accent)

plt.scatter(petal_l, petal_w,
            c=target,
            edgecolor='black',
            cmap=plt.cm.Accent,
            s=60)

plt.title('Границы классификации', pad=15)
plt.xlabel('Petal length', fontsize=12)
plt.ylabel('Petal width', fontsize=12)
plt.grid(True, alpha=0.5)

plt.show()