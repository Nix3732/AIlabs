import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

df = pd.read_csv('Titanic.csv')
value_data = len(df)

df = df.dropna()

df = df.drop(['Name', 'Ticket', 'Cabin'], axis=1)

df['Sex'] = df['Sex'].map({'male': 0, 'female': 1})
df['Embarked'] = df['Embarked'].map({'C': 1, 'Q': 2, 'S': 3})

df = df.drop('PassengerId', axis=1)

value_data_clean = len(df)

percent = (1-(value_data_clean / value_data))*100

print(f'Процент потерянных данных: {percent:.4f}%')

X = df.drop('Survived', axis=1)
Y = df['Survived']


X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.25, random_state=42)

clf = LogisticRegression(max_iter=1000, random_state=0)
clf.fit(X_train, Y_train)
Y_pred = clf.predict(X_test)
acc1 = accuracy_score(Y_pred, Y_test)

print(f"Точность модели: {acc1:.4f}")

df = df.drop('Embarked', axis=1)

X = df.drop('Survived', axis=1)
Y = df['Survived']


X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.25, random_state=42)

clf = LogisticRegression(max_iter=1000, random_state=0)
clf.fit(X_train, Y_train)
Y_pred = clf.predict(X_test)
acc2 = accuracy_score(Y_pred, Y_test)

print(f"Точность модели: {acc2:.4f}")

print(f"Влияние Embarked: {acc2-acc1:.4f}")